# Faraby College Bot V4 — সহজ Setup

## Requirements
- Node.js 20+
- npm 7+
- A supported Facebook account/session setup for this bot
- Internet access

## Install
```bash
npm install
```

## Configure
Edit `config.json` and set your own admin UID, prefix and required credentials. Never share Facebook cookies, passwords or API secrets.

## Run
```bash
npm start
```

## 24/7 on a VPS
```bash
npm install -g pm2
pm2 start index.js --name faraby-college-bot
pm2 save
pm2 startup
```
Run the exact startup command printed by PM2, then run `pm2 save` again.

## Creator photo
Add your own photo as `assets/college/faraby.jpg`. The bot will attach it for creator queries.
