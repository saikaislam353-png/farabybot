const fs = require("fs-extra");
const path = require("path");

module.exports = {
  config: {
    name: "cmdlist",
    version: "4.0.0",
    author: "Faraby",
    countDown: 3,
    role: 0,
    category: "system",
    description: { bn: "Bot-এর command category ও ব্যবহার দেখায়", en: "Show command categories" },
    guide: { bn: "{pn}", en: "{pn}" }
  },
  onStart: async function ({ api, event }) {
    const files = fs.readdirSync(path.join(__dirname));
    const commands = files.filter(f => f.endsWith(".js")).length;
    const prefix = global.utils.getPrefix(event.threadID);
    return api.sendMessage(
      "╭━━〔 📋 FARABY COMMAND CENTER 〕━━╮\n" +
      "┃ মোট command files: " + commands + "+\n" +
      "┃\n" +
      "┃ 🎓 College\n" +
      "┃ 🤖 AI / Chat\n" +
      "┃ 🎵 Music / Audio\n" +
      "┃ 📥 Downloader\n" +
      "┃ 🖼️ Image / AI Art\n" +
      "┃ 🎮 Games / Quiz\n" +
      "┃ 💰 Economy / Rank\n" +
      "┃ 👥 Group Management\n" +
      "┃ 🛠️ Utility / System\n" +
      "┃ 🌐 Social / Search\n" +
      "┃\n" +
      "┃ 📖 Full command list: " + prefix + "help\n" +
      "┃ 🎓 College list: " + prefix + "college commands\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯",
      event.threadID, event.messageID
    );
  }
};
