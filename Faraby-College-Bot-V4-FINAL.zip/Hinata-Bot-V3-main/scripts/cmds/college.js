const fs = require("fs-extra");
const path = require("path");

module.exports = {
  config: {
    name: "college",
    version: "4.0.0",
    author: "Faraby",
    countDown: 3,
    role: 0,
    category: "college",
    description: {
      bn: "রূপদিয়া শহীদ স্মৃতি মহাবিদ্যালয়ের তথ্য, রুটিন, বিষয় ও সাহায্য",
      en: "Rupdia Shaheed Smrity College information and routine"
    },
    guide: {
      bn: "{pn} | {pn} routine | {pn} subjects | {pn} info | {pn} commands",
      en: "{pn} | {pn} routine | {pn} subjects | {pn} info | {pn} commands"
    }
  },

  onStart: async function ({ api, event, args }) {
    const sub = (args[0] || "").toLowerCase();
    const prefix = global.utils.getPrefix(event.threadID);

    if (["routine", "রুটিন", "class"].includes(sub)) {
      const file = path.join(__dirname, "../../assets/college/routine-2026-09-20.jpg");
      if (!fs.existsSync(file)) return api.sendMessage("❌ Routine file পাওয়া যায়নি।", event.threadID, event.messageID);
      return api.sendMessage({
        body: "🗓️ রূপদিয়া শহীদ স্মৃতি মহাবিদ্যালয়\n📚 একাদশ ও দ্বাদশ শ্রেণির রুটিন\n\n📌 কার্যকর: ২০/০৯/২০২৬ থেকে\n🕐 গাইড শিক্ষকের নিকট হাজিরা: ১২:০৫–১২:৫০\n\n⚠️ ব্যবহারিক ক্লাস সংশ্লিষ্ট রুটিন অনুযায়ী হবে।",
        attachment: fs.createReadStream(file)
      }, event.threadID, event.messageID);
    }

    if (["subjects", "subject", "বিষয়"].includes(sub)) {
      return api.sendMessage(
        "📚 কলেজের প্রধান গ্রুপ/বিষয়\n\n🔬 বিজ্ঞান\n👥 মানবিক\n💼 ব্যবসায় শিক্ষা\n\nতোমার নির্দিষ্ট বিষয় জানতে লিখো:\n" + prefix + "college subjects",
        event.threadID, event.messageID
      );
    }

    if (["info", "information", "তথ্য"].includes(sub)) {
      return api.sendMessage(
        "🎓 রূপদিয়া শহীদ স্মৃতি মহাবিদ্যালয়\n\n📍 রূপদিয়া, যশোর\n🆔 EIIN: 116103\n📚 শিক্ষা বোর্ড: যশোর\n🏫 প্রতিষ্ঠা: ৩ মে ১৯৯৯\n🌐 Website: https://www.rupdiacollege.edu.bd/\n\n" +
        "আরও জানতে: " + prefix + "college",
        event.threadID, event.messageID
      );
    }

    if (["commands", "cmd", "help", "কমান্ড"].includes(sub)) {
      return api.sendMessage(
        "🎓 COLLEGE BOT COMMANDS\n\n" +
        "🏫 " + prefix + "college — College menu\n" +
        "🗓️ " + prefix + "college routine — Class routine\n" +
        "📚 " + prefix + "college subjects — Subjects/groups\n" +
        "ℹ️ " + prefix + "college info — College information\n" +
        "👑 " + prefix + "creator — Bot creator\n" +
        "📋 " + prefix + "cmdlist — All command categories\n" +
        "🤖 " + prefix + "ai <question> — AI chat\n" +
        "🎵 " + prefix + "play <song> — Music\n" +
        "🌤️ " + prefix + "weather <city> — Weather\n" +
        "🎮 " + prefix + "quiz — Quiz\n" +
        "👤 " + prefix + "profile — Profile\n" +
        "📊 " + prefix + "rank — Rank\n\n" +
        "💡 সব মূল command দেখতে: " + prefix + "help",
        event.threadID, event.messageID
      );
    }

    return api.sendMessage(
      "╭━━━〔 🎓 FARABY COLLEGE BOT 〕━━━╮\n" +
      "┃ 🏫 রূপদিয়া শহীদ স্মৃতি মহাবিদ্যালয়\n" +
      "┃\n" +
      "┃ 🗓️ " + prefix + "college routine\n" +
      "┃ 📚 " + prefix + "college subjects\n" +
      "┃ ℹ️ " + prefix + "college info\n" +
      "┃ 👑 " + prefix + "creator\n" +
      "┃ 📋 " + prefix + "cmdlist\n" +
      "┃ 🤖 " + prefix + "ai <প্রশ্ন>\n" +
      "┃ 🎵 " + prefix + "play <গান>\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n" +
      "⚡ Powered by Faraby",
      event.threadID, event.messageID
    );
  }
};
