const fs = require("fs-extra");
const path = require("path");

module.exports = {
  config: {
    name: "creator",
    version: "4.0.0",
    author: "Faraby",
    countDown: 2,
    role: 0,
    category: "system",
    description: { bn: "Bot creator information", en: "Bot creator information" },
    guide: { bn: "{pn}", en: "{pn}" }
  },

  onStart: async function ({ api, event }) {
    const photo = path.join(__dirname, "../../assets/college/faraby.jpg");
    const body =
      "╭━━━〔 👑 BOT CREATOR 〕━━━╮\n" +
      "┃\n" +
      "┃ 👤 Creator: Faraby\n" +
      "┃ 🎓 Rupdia Shaheed Smrity College Bot\n" +
      "┃ 💻 Custom development & branding\n" +
      "┃\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n" +
      "❤️ এই Bot-টি Faraby-এর জন্য custom করা হয়েছে।";

    if (fs.existsSync(photo)) {
      return api.sendMessage({ body, attachment: fs.createReadStream(photo) }, event.threadID, event.messageID);
    }
    return api.sendMessage(body + "\n\n📸 Creator photo এখনো assets/college/faraby.jpg-এ যোগ করা হয়নি।", event.threadID, event.messageID);
  },

  onChat: async function ({ event, api }) {
    const text = String(event.body || "").toLowerCase().replace(/[!?.,]/g, " ");
    const patterns = [
      "বট কে বানাইছে", "বট কে বানিয়েছে", "বট কে বানিয়েছে", "বট কে বানাইছে", "বট বানাইছে কে",
      "কে বানাইছে বট", "কে বানিয়েছে বট", "creator কে", "who made this bot", "who made the bot",
      "developer কে", "developer", "বটের মালিক কে"
    ];
    if (!patterns.some(p => text.includes(p))) return;

    const photo = path.join(__dirname, "../../assets/college/faraby.jpg");
    const body = "👑 এই Bot-এর Creator: Faraby\n🎓 Rupdia Shaheed Smrity College Bot\n❤️ Powered by Faraby";
    if (fs.existsSync(photo)) return api.sendMessage({ body, attachment: fs.createReadStream(photo) }, event.threadID, event.messageID);
    return api.sendMessage(body, event.threadID, event.messageID);
  }
};
