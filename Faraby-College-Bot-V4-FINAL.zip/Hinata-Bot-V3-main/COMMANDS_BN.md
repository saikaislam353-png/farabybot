# Faraby College Bot V4 — Command Guide

Prefix is read from `config.json` (default: `!`). The original Hinata commands remain available.

## 🎓 College
- `!college` — College menu
- `!college routine` — একাদশ/দ্বাদশ রুটিন
- `!college subjects` — গ্রুপ/বিষয় তথ্য
- `!college info` — কলেজের তথ্য
- `!college commands` — College commands

## 👑 Creator
- `!creator` — Faraby creator information
- Natural text such as `বট কে বানাইছে` / `creator কে` — automatic creator reply
- To enable the creator photo, put your own photo at `assets/college/faraby.jpg`.

## 🤖 AI / Chat
- `!ai <question>`
- `!gpt <question>`
- `!gemini <question>`
- `!deepseek <question>`
- `!gemma <question>`

## 🎵 Music / Media
- `!play <song>` — music
- `!lyrics <song>` — lyrics
- `!audio <url>` — audio utility
- `!facebookdl <url>` — Facebook download where supported
- `!instagramdl <url>` — Instagram download where supported
- `!pinterestdl <url>` — Pinterest download where supported

## 🎮 Games / Quiz
- `!quiz`
- `!animalgame`
- `!animequiz`
- `!guessnumber`
- `!mathgame`
- `!footballgame`
- `!cricketgame`
- `!flaggame`

## 💰 Profile / Economy
- `!profile`
- `!rank`
- `!balance`
- `!daily`
- `!bank`

## 🖼️ Image / AI Art
Examples: `!4k`, `!blur`, `!cartoon`, `!ghibli`, `!draw`, `!removebg`, `!remini`, `!ocr`, `!sepia` where required APIs are configured.

## 👥 Group / Admin
Examples: `!ban`, `!kick`, `!pending`, `!filteruser`, `!grouptag`, `!admin`, `!rules` and the other commands shown by `!help`.

## 🛠️ System
- `!help` — full built-in help
- `!cmdlist` — category overview
- `!prefix` — prefix information
- `!ping` — response/status test
- `!restart` — restart command (permission may be required)

> Some original commands depend on external APIs, credentials, permissions, or third-party services.
